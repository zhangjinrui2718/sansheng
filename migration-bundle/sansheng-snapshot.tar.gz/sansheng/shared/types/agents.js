/**
 * Sansheng · 共享类型:Agents & Blackboard
 * M0/M1 占位 → M3a 增补 → M3b 落地 Blackboard + PlanStep + EvidenceItem 等结构。
 */
export {};
//# sourceMappingURL=agents.js.map
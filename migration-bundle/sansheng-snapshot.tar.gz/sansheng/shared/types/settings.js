/**
 * Sansheng 共享类型:Settings (M1.5 · 多 provider)
 */
export {};
//# sourceMappingURL=settings.js.map